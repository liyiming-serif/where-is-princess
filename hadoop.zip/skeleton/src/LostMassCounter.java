public enum LostMassCounter {
	LOST_MASS
}