import java.io.IOException;
import java.util.*;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.util.*;



public class TrustMapper extends Mapper<IntWritable, Node, IntWritable, NodeOrDouble> {

    public void map(IntWritable key, Node value, Context context) throws IOException, InterruptedException {

        //Implement 
        context.getCounter(SizeCounter.SIZE).increment(1); //remember to divide by this in reducer!!
        context.write(new IntWritable(value.nodeid), new NodeOrDouble(value));
        if (value.outgoing.length==0) {
            long increment_amount = (long)(value.pageRank*100000);
        	context.getCounter(LostMassCounter.LOST_MASS).increment(increment_amount); //remember to divide by this in reducer!!            
	        return; //take care of no outgoing nodes in Leftover
	    }
        double p = value.pageRank / value.outgoing.length;
        for (int nid: value.outgoing) {
        	context.write(new IntWritable(nid), new NodeOrDouble(p));
        }
    }
}
